package com.gym.gymapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
